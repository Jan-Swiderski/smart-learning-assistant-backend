# Getting Started

## Available commands

### initiate db on emty schema
`flask db init`
`flask db migrate -m "Initial migration"`

### preapare migration
`flask db migrate -m "Migration description"`

### aply migration
`flask db upgrade`
